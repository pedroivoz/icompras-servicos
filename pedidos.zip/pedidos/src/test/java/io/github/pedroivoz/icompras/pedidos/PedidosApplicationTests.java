package io.github.pedroivoz.icompras.pedidos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidosApplicationTests {

	@Test
	void contextLoads() {
	}

}
